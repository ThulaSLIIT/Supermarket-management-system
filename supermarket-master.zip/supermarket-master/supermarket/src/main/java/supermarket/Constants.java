package supermarket;

public class Constants {
	public static final String ELECTRICITY = "Electric Bill";
	public static final String CLEANING = "Cleaning";
	public static final String TRANSPORT = "Transport";
	public static final String OTHER = "Other";
	public static final String ADMIN = "Admin";
	public static final String STAFF = "Staff";
	public static final String CASHIER = "Cashier";
	public static final String SALES = "Sales";
	public static final String MANAGER = "Manager";
	public static final String VEGETABLES = "Vegetables";
	public static final String FRUITS = "Fruits";
	public static final String MEATS = "Meats";
	public static final String FISH = "Fish";
	public static final String BEVERAGES = "Beverages";
	public static final String GROCERY = "Grocery";
}
